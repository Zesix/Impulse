﻿using UnityEngine;

namespace Zenject.Tests.Bindings.FromSubContainerPrefab
{
    public interface IFoo
    {
    }

    public class Foo : MonoBehaviour, IFoo
    {
    }
}
